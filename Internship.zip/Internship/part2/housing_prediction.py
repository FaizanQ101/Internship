import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings('ignore')

# Set style for better plots
plt.style.use('seaborn-v0_8')
sns.set_palette("viridis")

def load_and_explore_data(file_path):
    """Load the California housing dataset and perform initial exploration"""
    print("=" * 70)
    print("CALIFORNIA HOUSING PRICE PREDICTION - DATA EXPLORATION")
    print("=" * 70)
    
    # Load the dataset
    try:
        df = pd.read_csv(file_path)
        print(f"✓ Dataset loaded successfully from: {file_path}")
    except FileNotFoundError:
        print(f"❌ File not found: {file_path}")
        print("Please ensure the housing.csv file is in the correct path.")
        return None
    
    print(f"\nDataset Shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    
    # Display basic information
    print("\n" + "-" * 50)
    print("DATASET INFO:")
    print("-" * 50)
    print(df.info())
    
    print("\n" + "-" * 50)
    print("FIRST 5 ROWS:")
    print("-" * 50)
    print(df.head())
    
    print("\n" + "-" * 50)
    print("STATISTICAL SUMMARY:")
    print("-" * 50)
    print(df.describe())
    
    # Check for missing values
    print("\n" + "-" * 50)
    print("MISSING VALUES:")
    print("-" * 50)
    missing_values = df.isnull().sum()
    print(missing_values)
    
    if missing_values.sum() > 0:
        print(f"⚠️  Found {missing_values.sum()} missing values that need to be handled")
    else:
        print("✓ No missing values found!")
    
    # Check ocean proximity distribution
    if 'ocean_proximity' in df.columns:
        print(f"\n" + "-" * 50)
        print("OCEAN PROXIMITY DISTRIBUTION:")
        print("-" * 50)
        print(df['ocean_proximity'].value_counts())
    
    # Check target variable distribution
    if 'median_house_value' in df.columns:
        print(f"\n" + "-" * 50)
        print("TARGET VARIABLE (MEDIAN HOUSE VALUE) STATS:")
        print("-" * 50)
        print(f"Mean: ${df['median_house_value'].mean():,.2f}")
        print(f"Median: ${df['median_house_value'].median():,.2f}")
        print(f"Min: ${df['median_house_value'].min():,.2f}")
        print(f"Max: ${df['median_house_value'].max():,.2f}")
    
    return df

def visualize_data(df):
    """Create comprehensive visualizations of the housing dataset"""
    print("\n" + "=" * 70)
    print("DATA VISUALIZATION")
    print("=" * 70)
    
    # Target variable distribution
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('California Housing Dataset - Key Visualizations', fontsize=16, fontweight='bold')
    
    # 1. House value distribution
    axes[0, 0].hist(df['median_house_value'], bins=50, alpha=0.7, color='skyblue', edgecolor='black')
    axes[0, 0].set_xlabel('Median House Value ($)')
    axes[0, 0].set_ylabel('Frequency')
    axes[0, 0].set_title('Distribution of House Values')
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Geographic distribution
    scatter = axes[0, 1].scatter(df['longitude'], df['latitude'], 
                                c=df['median_house_value'], cmap='viridis', 
                                alpha=0.6, s=10)
    axes[0, 1].set_xlabel('Longitude')
    axes[0, 1].set_ylabel('Latitude')
    axes[0, 1].set_title('Geographic Distribution of House Values')
    plt.colorbar(scatter, ax=axes[0, 1], label='Median House Value ($)')
    
    # 3. Income vs House Value
    axes[1, 0].scatter(df['median_income'], df['median_house_value'], alpha=0.5, s=10)
    axes[1, 0].set_xlabel('Median Income')
    axes[1, 0].set_ylabel('Median House Value ($)')
    axes[1, 0].set_title('Income vs House Value')
    axes[1, 0].grid(True, alpha=0.3)
    
    # 4. Ocean proximity impact
    sns.boxplot(data=df, x='ocean_proximity', y='median_house_value', ax=axes[1, 1])
    axes[1, 1].set_xlabel('Ocean Proximity')
    axes[1, 1].set_ylabel('Median House Value ($)')
    axes[1, 1].set_title('House Values by Ocean Proximity')
    axes[1, 1].tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.show()
    
    # Correlation heatmap
    plt.figure(figsize=(12, 10))
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    correlation_matrix = df[numeric_cols].corr()
    
    mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
    sns.heatmap(correlation_matrix, mask=mask, annot=True, cmap='coolwarm', 
                center=0, square=True, linewidths=0.5, fmt='.2f')
    plt.title('Feature Correlation Heatmap', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()
    
    # Feature distributions
    fig, axes = plt.subplots(3, 3, figsize=(18, 15))
    fig.suptitle('Feature Distributions', fontsize=16, fontweight='bold')
    
    numeric_features = ['housing_median_age', 'total_rooms', 'total_bedrooms', 
                       'population', 'households', 'median_income']
    
    for i, feature in enumerate(numeric_features):
        row, col = i // 3, i % 3
        axes[row, col].hist(df[feature], bins=30, alpha=0.7, color='lightcoral', edgecolor='black')
        axes[row, col].set_xlabel(feature.replace('_', ' ').title())
        axes[row, col].set_ylabel('Frequency')
        axes[row, col].set_title(f'{feature.replace("_", " ").title()} Distribution')
        axes[row, col].grid(True, alpha=0.3)
    
    # Remove empty subplots
    for i in range(len(numeric_features), 9):
        row, col = i // 3, i % 3
        fig.delaxes(axes[row, col])
    
    plt.tight_layout()
    plt.show()

def clean_and_engineer_features(df):
    """Clean data and engineer new features"""
    print("\n" + "=" * 70)
    print("DATA CLEANING AND FEATURE ENGINEERING")
    print("=" * 70)
    
    # Make a copy to avoid modifying original data
    df_clean = df.copy()
    
    # Handle missing values
    print("🧹 Handling missing values...")
    missing_before = df_clean.isnull().sum().sum()
    
    # Fill missing total_bedrooms with median
    if df_clean['total_bedrooms'].isnull().sum() > 0:
        median_bedrooms = df_clean['total_bedrooms'].median()
        df_clean['total_bedrooms'].fillna(median_bedrooms, inplace=True)
        print(f"✓ Filled {df_clean['total_bedrooms'].isnull().sum()} missing bedroom values with median: {median_bedrooms}")
    
    missing_after = df_clean.isnull().sum().sum()
    print(f"✓ Missing values reduced from {missing_before} to {missing_after}")
    
    # Feature Engineering
    print("\n🔧 Engineering new features...")
    
    # 1. Rooms per household
    df_clean['rooms_per_household'] = df_clean['total_rooms'] / df_clean['households']
    
    # 2. Bedrooms per room
    df_clean['bedrooms_per_room'] = df_clean['total_bedrooms'] / df_clean['total_rooms']
    
    # 3. Population per household
    df_clean['population_per_household'] = df_clean['population'] / df_clean['households']
    
    # 4. Income categories
    df_clean['income_category'] = pd.cut(df_clean['median_income'], 
                                        bins=[0, 1.5, 3.0, 4.5, 6.0, np.inf],
                                        labels=['Very Low', 'Low', 'Medium', 'High', 'Very High'])
    
    # 5. Age categories
    df_clean['age_category'] = pd.cut(df_clean['housing_median_age'],
                                     bins=[0, 10, 20, 30, 40, np.inf],
                                     labels=['New', 'Recent', 'Medium', 'Old', 'Very Old'])
    
    print(f"✓ Created 5 new features:")
    print(f"  - rooms_per_household")
    print(f"  - bedrooms_per_room") 
    print(f"  - population_per_household")
    print(f"  - income_category")
    print(f"  - age_category")
    
    # Remove outliers (optional - using IQR method for house values)
    print("\n🎯 Handling outliers...")
    Q1 = df_clean['median_house_value'].quantile(0.25)
    Q3 = df_clean['median_house_value'].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    outliers_before = len(df_clean)
    df_clean = df_clean[(df_clean['median_house_value'] >= lower_bound) & 
                       (df_clean['median_house_value'] <= upper_bound)]
    outliers_removed = outliers_before - len(df_clean)
    
    print(f"✓ Removed {outliers_removed} outliers from house values")
    print(f"✓ Dataset shape after cleaning: {df_clean.shape}")
    
    return df_clean

def prepare_features(df):
    """Prepare features for machine learning"""
    print("\n" + "=" * 70)
    print("FEATURE PREPARATION")
    print("=" * 70)
    
    # Define target variable
    target = 'median_house_value'
    y = df[target].values
    
    # Define feature categories
    numeric_features = ['longitude', 'latitude', 'housing_median_age', 'total_rooms',
                       'total_bedrooms', 'population', 'households', 'median_income',
                       'rooms_per_household', 'bedrooms_per_room', 'population_per_household']
    
    categorical_features = ['ocean_proximity', 'income_category', 'age_category']
    
    # Select features that exist in the dataframe
    available_numeric = [col for col in numeric_features if col in df.columns]
    available_categorical = [col for col in categorical_features if col in df.columns]
    
    print(f"✓ Numeric features ({len(available_numeric)}): {available_numeric}")
    print(f"✓ Categorical features ({len(available_categorical)}): {available_categorical}")
    
    # Create feature matrix
    X = df[available_numeric + available_categorical].copy()
    
    # Create preprocessing pipeline
    numeric_transformer = StandardScaler()
    categorical_transformer = OneHotEncoder(drop='first', sparse_output=False)
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, available_numeric),
            ('cat', categorical_transformer, available_categorical)
        ])
    
    print(f"✓ Target variable: {target}")
    print(f"✓ Feature matrix shape: {X.shape}")
    print(f"✓ Target vector shape: {y.shape}")
    
    return X, y, preprocessor, available_numeric, available_categorical

def train_and_evaluate_models(X, y, preprocessor):
    """Train multiple regression models and evaluate their performance"""
    print("\n" + "=" * 70)
    print("MODEL TRAINING AND EVALUATION")
    print("=" * 70)
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"✓ Training set size: {X_train.shape[0]} samples")
    print(f"✓ Test set size: {X_test.shape[0]} samples")
    
    # Define models to try
    models = {
        'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
        'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
        'Linear Regression': LinearRegression(),
        'Ridge Regression': Ridge(alpha=1.0),
        'Lasso Regression': Lasso(alpha=1.0),
    }
    
    results = {}
    
    print("Training and evaluating models...")
    print("-" * 60)
    
    for name, model in models.items():
        print(f"\n🔄 Training {name}...")
        
        # Create pipeline with preprocessing
        pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('regressor', model)
        ])
        
        # Train the model
        pipeline.fit(X_train, y_train)
        
        # Make predictions
        y_pred_train = pipeline.predict(X_train)
        y_pred_test = pipeline.predict(X_test)
        
        # Calculate metrics
        train_rmse = np.sqrt(mean_squared_error(y_train, y_pred_train))
        test_rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
        train_mae = mean_absolute_error(y_train, y_pred_train)
        test_mae = mean_absolute_error(y_test, y_pred_test)
        train_r2 = r2_score(y_train, y_pred_train)
        test_r2 = r2_score(y_test, y_pred_test)
        
        # Cross-validation
        cv_scores = cross_val_score(pipeline, X_train, y_train, 
                                   cv=5, scoring='neg_root_mean_squared_error')
        cv_rmse = -cv_scores.mean()
        cv_std = cv_scores.std()
        
        results[name] = {
            'pipeline': pipeline,
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_mae': train_mae,
            'test_mae': test_mae,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'cv_rmse': cv_rmse,
            'cv_std': cv_std,
            'predictions': y_pred_test
        }
        
        print(f"✓ Test RMSE: ${test_rmse:,.2f}")
        print(f"✓ Test MAE: ${test_mae:,.2f}")
        print(f"✓ Test R²: {test_r2:.4f}")
        print(f"✓ CV RMSE: ${cv_rmse:,.2f} (±{cv_std:,.2f})")
    
    # Find best model (lowest test RMSE)
    best_model_name = min(results.keys(), key=lambda x: results[x]['test_rmse'])
    best_pipeline = results[best_model_name]['pipeline']
    best_rmse = results[best_model_name]['test_rmse']
    
    print(f"\n🏆 BEST MODEL: {best_model_name}")
    print(f"🎯 BEST RMSE: ${best_rmse:,.2f}")
    
    # Detailed evaluation of best model
    print(f"\n" + "=" * 70)
    print(f"DETAILED EVALUATION - {best_model_name.upper()}")
    print("=" * 70)
    
    best_results = results[best_model_name]
    print(f"Training RMSE: ${best_results['train_rmse']:,.2f}")
    print(f"Test RMSE: ${best_results['test_rmse']:,.2f}")
    print(f"Training MAE: ${best_results['train_mae']:,.2f}")
    print(f"Test MAE: ${best_results['test_mae']:,.2f}")
    print(f"Training R²: {best_results['train_r2']:.4f}")
    print(f"Test R²: {best_results['test_r2']:.4f}")
    
    # Plot actual vs predicted
    plt.figure(figsize=(15, 5))
    
    # Subplot 1: Actual vs Predicted
    plt.subplot(1, 3, 1)
    plt.scatter(y_test, best_results['predictions'], alpha=0.5)
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
    plt.xlabel('Actual House Value ($)')
    plt.ylabel('Predicted House Value ($)')
    plt.title(f'Actual vs Predicted - {best_model_name}')
    plt.grid(True, alpha=0.3)
    
    # Subplot 2: Residuals
    plt.subplot(1, 3, 2)
    residuals = y_test - best_results['predictions']
    plt.scatter(best_results['predictions'], residuals, alpha=0.5)
    plt.axhline(y=0, color='r', linestyle='--')
    plt.xlabel('Predicted House Value ($)')
    plt.ylabel('Residuals ($)')
    plt.title('Residual Plot')
    plt.grid(True, alpha=0.3)
    
    # Subplot 3: Model comparison
    plt.subplot(1, 3, 3)
    model_names = list(results.keys())
    test_rmses = [results[name]['test_rmse'] for name in model_names]
    
    bars = plt.bar(model_names, test_rmses, alpha=0.7)
    plt.xlabel('Models')
    plt.ylabel('Test RMSE ($)')
    plt.title('Model Performance Comparison')
    plt.xticks(rotation=45, ha='right')
    plt.grid(True, alpha=0.3)
    
    # Highlight best model
    best_idx = model_names.index(best_model_name)
    bars[best_idx].set_color('gold')
    
    plt.tight_layout()
    plt.show()
    
    return best_pipeline, best_model_name, results, X_test, y_test

def feature_importance_analysis(pipeline, feature_names):
    """Analyze feature importance for the best model"""
    print(f"\n" + "=" * 70)
    print("FEATURE IMPORTANCE ANALYSIS")
    print("=" * 70)
    
    # Get the trained model from pipeline
    model = pipeline.named_steps['regressor']
    
    # Check if model has feature_importances_
    if hasattr(model, 'feature_importances_'):
        # Get feature names after preprocessing
        preprocessor = pipeline.named_steps['preprocessor']
        
        # Get feature names from ColumnTransformer
        feature_names_transformed = []
        
        # Numeric features
        numeric_features = preprocessor.transformers_[0][2]
        feature_names_transformed.extend(numeric_features)
        
        # Categorical features (after one-hot encoding)
        if len(preprocessor.transformers_) > 1:
            cat_encoder = preprocessor.transformers_[1][1]
            cat_features = preprocessor.transformers_[1][2]
            if hasattr(cat_encoder, 'get_feature_names_out'):
                cat_feature_names = cat_encoder.get_feature_names_out(cat_features)
                feature_names_transformed.extend(cat_feature_names)
        
        # Get importance scores
        importances = model.feature_importances_
        
        # Create feature importance dataframe
        feature_importance_df = pd.DataFrame({
            'feature': feature_names_transformed[:len(importances)],
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        print("TOP 10 MOST IMPORTANT FEATURES:")
        print("-" * 40)
        for i, (_, row) in enumerate(feature_importance_df.head(10).iterrows(), 1):
            print(f"{i:2d}. {row['feature']:<25} {row['importance']:.4f}")
        
        # Plot feature importance
        plt.figure(figsize=(12, 8))
        top_features = feature_importance_df.head(15)
        
        plt.barh(range(len(top_features)), top_features['importance'])
        plt.yticks(range(len(top_features)), top_features['feature'])
        plt.xlabel('Feature Importance')
        plt.title('Top 15 Feature Importances')
        plt.gca().invert_yaxis()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()
        
        return feature_importance_df
    else:
        print("ℹ️  Selected model doesn't provide feature importance scores")
        return None

def make_predictions(pipeline, preprocessor, feature_names):
    """Function to make predictions on new data"""
    print(f"\n" + "=" * 70)
    print("PREDICTION FUNCTION")
    print("=" * 70)
    
    def predict_house_price(longitude, latitude, housing_median_age, total_rooms,
                           total_bedrooms, population, households, median_income,
                           ocean_proximity):
        """Predict house price for given features"""
        
        # Create feature dictionary
        features = {
            'longitude': longitude,
            'latitude': latitude,
            'housing_median_age': housing_median_age,
            'total_rooms': total_rooms,
            'total_bedrooms': total_bedrooms,
            'population': population,
            'households': households,
            'median_income': median_income,
            'ocean_proximity': ocean_proximity
        }
        
        # Calculate engineered features
        features['rooms_per_household'] = total_rooms / households
        features['bedrooms_per_room'] = total_bedrooms / total_rooms
        features['population_per_household'] = population / households
        
        # Create income category
        if median_income <= 1.5:
            features['income_category'] = 'Very Low'
        elif median_income <= 3.0:
            features['income_category'] = 'Low'
        elif median_income <= 4.5:
            features['income_category'] = 'Medium'
        elif median_income <= 6.0:
            features['income_category'] = 'High'
        else:
            features['income_category'] = 'Very High'
        
        # Create age category
        if housing_median_age <= 10:
            features['age_category'] = 'New'
        elif housing_median_age <= 20:
            features['age_category'] = 'Recent'
        elif housing_median_age <= 30:
            features['age_category'] = 'Medium'
        elif housing_median_age <= 40:
            features['age_category'] = 'Old'
        else:
            features['age_category'] = 'Very Old'
        
        # Create dataframe
        input_df = pd.DataFrame([features])
        
        # Make prediction
        prediction = pipeline.predict(input_df)[0]
        
        print(f"\nPrediction for:")
        print(f"  Location: ({longitude}, {latitude})")
        print(f"  Housing Age: {housing_median_age} years")
        print(f"  Total Rooms: {total_rooms}")
        print(f"  Total Bedrooms: {total_bedrooms}")
        print(f"  Population: {population}")
        print(f"  Households: {households}")
        print(f"  Median Income: ${median_income}")
        print(f"  Ocean Proximity: {ocean_proximity}")
        print(f"\n🏠 Predicted House Value: ${prediction:,.2f}")
        
        return prediction
    
    # Example predictions
    print("\nExample Predictions:")
    print("-" * 40)
    
    # Example 1: Expensive area (near ocean, high income)
    print("\n1. High-value area prediction:")
    predict_house_price(-122.23, 37.88, 21, 7099, 1106, 2401, 1138, 8.3014, 'NEAR OCEAN')
    
    # Example 2: Moderate area (inland, medium income)
    print("\n2. Moderate-value area prediction:")
    predict_house_price(-121.22, 39.43, 25, 5320, 1171, 2984, 1235, 3.2031, 'INLAND')
    
    # Example 3: Lower value area (island, lower income)
    print("\n3. Lower-value area prediction:")
    predict_house_price(-119.56, 34.27, 28, 1675, 521, 744, 331, 1.7812, 'ISLAND')
    
    return predict_house_price

def main():
    """Main function to run the complete pipeline"""
    print("🏠 CALIFORNIA HOUSING PRICE PREDICTION PROJECT 🏠")
    print("ARCH TECHNOLOGIES - Artificial Intelligence Task 2")
    print("=" * 80)
    
    # File path
    file_path = r"C:\Internship\part2\housing.csv"
    
    # Step 1: Load and explore data
    df = load_and_explore_data(file_path)
    if df is None:
        return
    
    # Step 2: Visualize data
    visualize_data(df)
    
    # Step 3: Clean data and engineer features
    df_clean = clean_and_engineer_features(df)
    
    # Step 4: Prepare features
    X, y, preprocessor, numeric_features, categorical_features = prepare_features(df_clean)
    
    # Step 5: Train and evaluate models
    best_pipeline, best_model_name, results, X_test, y_test = train_and_evaluate_models(
        X, y, preprocessor
    )
    
    # Step 6: Feature importance analysis
    feature_importance_df = feature_importance_analysis(
        best_pipeline, numeric_features + categorical_features
    )
    
    # Step 7: Create prediction function
    predict_function = make_predictions(best_pipeline, preprocessor, 
                                       numeric_features + categorical_features)
    
    # Final summary
    print(f"\n" + "=" * 80)
    print("PROJECT SUMMARY")
    print("=" * 80)
    print(f"✅ Data cleaning and feature engineering completed")
    print(f"✅ {len(results)} regression models trained and evaluated")
    print(f"✅ Best model: {best_model_name}")
    print(f"✅ Best RMSE: ${results[best_model_name]['test_rmse']:,.2f}")
    print(f"✅ Best R² Score: {results[best_model_name]['test_r2']:.4f}")
    if feature_importance_df is not None:
        print(f"✅ Feature importance analysis completed")
    print(f"✅ Prediction function created and tested")

if __name__ == "__main__":
    main()