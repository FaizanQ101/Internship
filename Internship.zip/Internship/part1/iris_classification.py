import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.tree import DecisionTreeClassifier
import warnings
warnings.filterwarnings('ignore')

#style for better plots
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

def load_and_explore_data(file_path):
    """Load the Iris dataset and perform initial exploration"""
    print("=" * 60)
    print("IRIS FLOWER CLASSIFICATION - DATA EXPLORATION")
    print("=" * 60)
    
    #Load the dataset
    try:
        df = pd.read_csv(file_path)
        print(f"✓ Dataset loaded successfully from: {file_path}")
    except FileNotFoundError:
        print(f"❌ File not found: {file_path}")
        print("Please ensure the iris.csv file is in the correct path.")
        return None
    
    print(f"\nDataset Shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    
    #Display basic information
    print("\n" + "-" * 40)
    print("DATASET INFO:")
    print("-" * 40)
    print(df.info())
    
    print("\n" + "-" * 40)
    print("FIRST 5 ROWS:")
    print("-" * 40)
    print(df.head())
    
    print("\n" + "-" * 40)
    print("STATISTICAL SUMMARY:")
    print("-" * 40)
    print(df.describe())
    
    # Check for missing values
    print("\n" + "-" * 40)
    print("MISSING VALUES:")
    print("-" * 40)
    missing_values = df.isnull().sum()
    print(missing_values)
    
    if missing_values.sum() == 0:
        print("✓ No missing values found!")
    
    # Check species distribution
    if 'species' in df.columns or 'Species' in df.columns:
        species_col = 'species' if 'species' in df.columns else 'Species'
        print(f"\n" + "-" * 40)
        print("SPECIES DISTRIBUTION:")
        print("-" * 40)
        print(df[species_col].value_counts())
    
    return df

def visualize_data(df):
    """Create comprehensive visualizations of the Iris dataset"""
    print("\n" + "=" * 60)
    print("DATA VISUALIZATION")
    print("=" * 60)
    
    #Identify feature columns (assuming species is the target)
    feature_cols = [col for col in df.columns if col.lower() not in ['species', 'id']]
    species_col = 'species' if 'species' in df.columns else 'Species'
    
    #Create subplots
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Iris Dataset - Feature Distributions by Species', fontsize=16, fontweight='bold')
    
    #Plot distributions for each feature
    for i, feature in enumerate(feature_cols[:4]):
        ax = axes[i//2, i%2]
        for species in df[species_col].unique():
            species_data = df[df[species_col] == species][feature]
            ax.hist(species_data, alpha=0.7, label=species, bins=15)
        ax.set_xlabel(feature.replace('_', ' ').title())
        ax.set_ylabel('Frequency')
        ax.set_title(f'{feature.replace("_", " ").title()} Distribution')
        ax.legend()
        ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
    
    # Correlation heatmap
    plt.figure(figsize=(10, 8))
    correlation_matrix = df[feature_cols].corr()
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0, 
                square=True, linewidths=0.5)
    plt.title('Feature Correlation Heatmap', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()
    
    # Pairplot
    plt.figure(figsize=(12, 10))
    sns.pairplot(df, hue=species_col, diag_kind='hist', markers=['o', 's', 'D'])
    plt.suptitle('Iris Dataset - Pairwise Feature Relationships', y=1.02, fontsize=16, fontweight='bold')
    plt.show()

def preprocess_data(df):
    """Preprocess the data for machine learning"""
    print("\n" + "=" * 60)
    print("DATA PREPROCESSING")
    print("=" * 60)
    
    # Identify columns
    feature_cols = [col for col in df.columns if col.lower() not in ['species', 'id']]
    species_col = 'species' if 'species' in df.columns else 'Species'
    
    # Prepare features and target
    X = df[feature_cols].values
    y = df[species_col].values
    
    print(f"✓ Features selected: {feature_cols}")
    print(f"✓ Target variable: {species_col}")
    print(f"✓ Feature matrix shape: {X.shape}")
    print(f"✓ Target vector shape: {y.shape}")
    
    # Encode target labels if they are strings
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    
    print(f"✓ Target classes: {le.classes_}")
    print(f"✓ Encoded target shape: {y_encoded.shape}")
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )
    
    print(f"✓ Training set size: {X_train.shape[0]} samples")
    print(f"✓ Test set size: {X_test.shape[0]} samples")
    
    # Scale the features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    print("✓ Feature scaling completed")
    
    return X_train_scaled, X_test_scaled, y_train, y_test, le, scaler, feature_cols

def train_and_evaluate_models(X_train, X_test, y_train, y_test, le):
    """Train multiple models and evaluate their performance"""
    print("\n" + "=" * 60)
    print("MODEL TRAINING AND EVALUATION")
    print("=" * 60)
    
    # Define models to try
    models = {
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
        'Support Vector Machine': SVC(kernel='rbf', random_state=42),
        'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5),
        'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
        'Decision Tree': DecisionTreeClassifier(random_state=42)
    }
    
    results = {}
    
    print("Training and evaluating models...")
    print("-" * 50)
    
    for name, model in models.items():
        print(f"\n🔄 Training {name}...")
        
        # Train the model
        model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Calculate accuracy
        accuracy = accuracy_score(y_test, y_pred)
        
        # Cross-validation score
        cv_scores = cross_val_score(model, X_train, y_train, cv=5)
        
        results[name] = {
            'model': model,
            'accuracy': accuracy,
            'cv_mean': cv_scores.mean(),
            'cv_std': cv_scores.std(),
            'predictions': y_pred
        }
        
        print(f"✓ Test Accuracy: {accuracy:.4f}")
        print(f"✓ CV Score: {cv_scores.mean():.4f} (±{cv_scores.std():.4f})")
    
    # Find best model
    best_model_name = max(results.keys(), key=lambda x: results[x]['accuracy'])
    best_model = results[best_model_name]['model']
    best_accuracy = results[best_model_name]['accuracy']
    
    print(f"\n🏆 BEST MODEL: {best_model_name}")
    print(f"🎯 BEST ACCURACY: {best_accuracy:.4f}")
    
    # Detailed evaluation of best model
    print(f"\n" + "=" * 60)
    print(f"DETAILED EVALUATION - {best_model_name.upper()}")
    print("=" * 60)
    
    best_predictions = results[best_model_name]['predictions']
    
    # Classification report
    print("\nCLASSIFICATION REPORT:")
    print("-" * 30)
    print(classification_report(y_test, best_predictions, target_names=le.classes_))
    
    # Confusion matrix
    print("\nCONFUSION MATRIX:")
    print("-" * 20)
    cm = confusion_matrix(y_test, best_predictions)
    print(cm)
    
    # Plot confusion matrix
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=le.classes_, yticklabels=le.classes_)
    plt.title(f'Confusion Matrix - {best_model_name}', fontsize=14, fontweight='bold')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.tight_layout()
    plt.show()
    
    # Model comparison plot
    model_names = list(results.keys())
    accuracies = [results[name]['accuracy'] for name in model_names]
    cv_means = [results[name]['cv_mean'] for name in model_names]
    
    plt.figure(figsize=(12, 6))
    x = np.arange(len(model_names))
    width = 0.35
    
    plt.bar(x - width/2, accuracies, width, label='Test Accuracy', alpha=0.8)
    plt.bar(x + width/2, cv_means, width, label='CV Mean Accuracy', alpha=0.8)
    
    plt.xlabel('Models')
    plt.ylabel('Accuracy')
    plt.title('Model Performance Comparison', fontsize=14, fontweight='bold')
    plt.xticks(x, model_names, rotation=45, ha='right')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()
    
    return best_model, best_model_name, results

def make_predictions(model, scaler, le, feature_cols):
    """Function to make predictions on new data"""
    print(f"\n" + "=" * 60)
    print("PREDICTION FUNCTION")
    print("=" * 60)
    
    def predict_iris_species(sepal_length, sepal_width, petal_length, petal_width):
        """Predict iris species for given measurements"""
        # Create feature array
        features = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
        
        # Scale features
        features_scaled = scaler.transform(features)
        
        # Make prediction
        prediction = model.predict(features_scaled)[0]
        probabilities = model.predict_proba(features_scaled)[0] if hasattr(model, 'predict_proba') else None
        
        # Get species name
        species_name = le.inverse_transform([prediction])[0]
        
        print(f"\nPrediction for:")
        print(f"  Sepal Length: {sepal_length} cm")
        print(f"  Sepal Width: {sepal_width} cm")
        print(f"  Petal Length: {petal_length} cm")
        print(f"  Petal Width: {petal_width} cm")
        print(f"\n🌸 Predicted Species: {species_name}")
        
        if probabilities is not None:
            print(f"\nPrediction Probabilities:")
            for i, class_name in enumerate(le.classes_):
                print(f"  {class_name}: {probabilities[i]:.4f}")
        
        return species_name
    
  
def main():
    """Main function to run the complete pipeline"""
    print("🌸 IRIS FLOWER CLASSIFICATION PROJECT 🌸")
    print("ARCH TECHNOLOGIES - Artificial Intelligence Task 1")
    print("=" * 70)
    
    # File path
    file_path = r"C:\Internship\part1\iris.csv"
    
    # Step 1: Load and explore data
    df = load_and_explore_data(file_path)
    if df is None:
        return
    
    # Step 2: Visualize data
    visualize_data(df)
    
    # Step 3: Preprocess data
    X_train, X_test, y_train, y_test, le, scaler, feature_cols = preprocess_data(df)
    
    # Step 4: Train and evaluate models
    best_model, best_model_name, results = train_and_evaluate_models(
        X_train, X_test, y_train, y_test, le
    )
    
    # Step 5: Create prediction function
    predict_function = make_predictions(best_model, scaler, le, feature_cols)
    
    # Final summary
    print(f"\n" + "=" * 70)
    print("PROJECT SUMMARY")
    print("=" * 70)
    print(f"✅ Data preprocessing completed successfully")
    print(f"✅ {len(results)} models trained and evaluated")
    print(f"✅ Best model: {best_model_name}")
    print(f"✅ Best accuracy: {results[best_model_name]['accuracy']:.4f}")
    print(f"✅ Prediction function created and tested")
    print("=" * 70)

if __name__ == "__main__":
    main()